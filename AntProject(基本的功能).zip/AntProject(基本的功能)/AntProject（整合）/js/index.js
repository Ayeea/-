window.onload=function(){
	var tree=document.getElementById("tree");
	tree.ontouchstart=function(){
		tree.className="";
		tree.className="move";
		setTimeout(function(){
			tree.className="";
		},1200)
	}
 }