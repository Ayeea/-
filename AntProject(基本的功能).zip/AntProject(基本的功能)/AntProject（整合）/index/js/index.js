window.onload=function(){
	var tree=document.getElementById("tree");
	tree.ontouchstart=function(){
		tree.className="";
		// alert("000");
		tree.className="move";
		// alert("111");
		setTimeout(function(){
			tree.className="";
		},1200)
		// alert("222");
	}
 }